from exploit_api import newb
from exploit_api.main import gyat
import os
from exploit_api.titties.instance import Instance
from exploit_api.titties.api import Memopy
import ctypes
import requests # type: ignore
from exploit_api.titties.utils import Offsets
import win32gui # type: ignore
import time
from pyfiglet import figlet_format as ascii
from exploit_api.titties.auto_dumper.offset_dumper import main as dump
import win32process
from exploit_api.titties.utils import GetRenderViewFromLog

main_dir = os.path.dirname(os.path.abspath(__file__))
autoexec_path = os.path.join(main_dir, "autoexec")
Window = None
Process = Memopy(0)
RenderView = GetRenderViewFromLog()
logo = ascii("ZENC")
global proto
proto = gyat()
proto.SetAutoExecPath(autoexec_path)
plrname = None
errors = {
    0x0: "Welcome to Zenc Beta!",
    0x1: "Injecting!",
    0x2: "Failed to find Roblox process.",
    0x3: "An error occured. Please submit a bug report with the code: Failed to fetch datamodel :(",
    0x4: "An error occured. Please submit a bug report with the code: Failed to fetch certain modules.",
    0x5: "An error occured. Please submit a bug report with the code: Roblox terminated while injecting!",
    0x6: "An error occured. Please submit a bug report with the code: Failed to find Bridge!"
}

titles = {
     0x0: "Zenc",
     0x1: "Zenc",
     0x2: "Zenc",
     0x3: "Zenc",
     0x4: "Zenc",
     0x5: "Zenc",
     0x6: "Zenc"
}


if __name__ == "__main__":
    os.system("title Zenc")
    os.system("@echo off")
    os.system("cls")
    jk = 2
    if jk == 1:
        exit(0)
    else:
            if not win32gui.FindWindow(None, "Roblox"):
             while True:
                 time.sleep(2)
                 if not win32gui.FindWindow(None, "Roblox"):
                    print("Waiting for Roblox..")
                 else:
                      input("Roblox open! Press Enter once Roblox has fully loaded..")
                      break
            os.system('cls')
            print(logo)
            print("Zenc Executor - Beta")
            time.sleep(0.1)
            print("[*] Injecting modules...")
            time.sleep(0.1)
            print("[-] Injected modules!")
            time.sleep(0.1)
            print("Injected! Join a game, if you're in game please rejoin!")
            compiled = proto.Inject()
            print(errors.get(compiled, "An error occured. Please submit a bug report with the code: Unknown error"))   