from exploit_api import newb
from exploit_api.main import gyat
import os
import random
from exploit_api.titties.instance import Instance
from exploit_api.titties.api import Memopy
import ctypes
import requests # type: ignore
from exploit_api.titties.utils import Offsets
import win32gui # type: ignore
import time
from pyfiglet import figlet_format as ascii
from exploit_api.titties.auto_dumper.offset_dumper import main as dump
import win32process
from exploit_api.titties.utils import GetRenderViewFromLog
from exploit_api.titties.base import fetch_roblox_pid, initialize
from exploit_api.titties.bytecode import Bytecode as RBXBytecode
from exploit_api.titties.bridge import Bridge as RBXBridge
from exploit_api.titties.instance import Instance, FetchRenderView, Process, Offsets
def fetch_roblox_pid():
    global Window, Process

    Window = win32gui.FindWindow(None, "Roblox")
    ProcessId = win32process.GetWindowThreadProcessId(Window)[1]

    return ProcessId

def initialize():
    ProcessId = fetch_roblox_pid()
    Process.update_pid(ProcessId)

    if not Process.process_handle:
        return False, -1
    
    return True, ProcessId

def main():
    success, pid = initialize()
    if success:
        print("[+] Found Roblox: "+str(pid))
        time.sleep(0.1)
        print("[*] Getting datamodel..")
        time.sleep(1)

       # Process.suspend()

        RenderView = GetRenderViewFromLog()

        datamodel_ptr = Process.read_longlong(RenderView + 0x118)
        datamodel = Process.read_longlong(datamodel_ptr + 0x198)
        DataModelAddyHolder = Process.read_longlong(RenderView + Offsets.DataModelHolder)
        DataModelAddy = Process.read_longlong(DataModelAddyHolder + Offsets.DataModel) if DataModelAddyHolder else None
        DataModel = Instance(DataModelAddy)
        return hex(datamodel)
main_dir = os.path.dirname(os.path.abspath(__file__))
autoexec_path = os.path.join(main_dir, "autoexec")
Window = None
Process = Memopy(0)
RenderView = GetRenderViewFromLog()
global proto
proto = gyat()
proto.SetAutoExecPath(autoexec_path)
plrname = None
errors = {
    0x0: "",
    0x1: "",
    0x2: "An error occured. Please open a ticket with the code: Failed to find Roblox process.",
    0x3: "An error occured. Please open a ticket with the code: Failed to fetch datamodel :(",
    0x4: "An error occured. Please open a ticket with the code: Failed to fetch certain modules.",
    0x5: "An error occured. Please open a ticket with the code: Roblox terminated while injecting!",
    0x6: "An error occured. Please open a ticket with the code: Failed to find Bridge!"
}

titles = {
     0x0: "Zenc",
     0x1: "Zenc",
     0x2: "Zenc",
     0x3: "Zenc",
     0x4: "Zenc",
     0x5: "Zenc",
     0x6: "Zenc"
}


if __name__ == "__main__":
    jk = 2
    if jk == 1:
        exit(0)
    else:
            if not win32gui.FindWindow(None, "Roblox"):
             while True:
                 time.sleep(2)
                 if not win32gui.FindWindow(None, "Roblox"):
                    print("Waiting for Roblox..")
                 else:
                      input("Roblox open! Press Enter once Roblox has fully loaded..")
                      break
            print("[+] Got Datamodel: "+ main())
            time.sleep(0.3)
            print("[*] Injecting modules...")
            time.sleep(0.2)
            print("[+] Injected modules!")
            print("")
            print("[!] Injected! Join a game, if you're in game please rejoin!")
            compiled = proto.Inject()
            print(errors.get(compiled, "An error occured. Please open a ticket with the code: Unknown error"))   